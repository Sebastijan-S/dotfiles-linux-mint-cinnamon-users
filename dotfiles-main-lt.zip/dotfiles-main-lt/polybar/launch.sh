#!/usr/bin/env bash

# Kill all existing polybar instances

# Wait to make sure everything shuts down
sleep 4

# Launch the bar after a small delay
(sleep 5 && polybar cebo) &
