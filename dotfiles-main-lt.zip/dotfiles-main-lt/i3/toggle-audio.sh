#!/bin/bash

HEADPHONES="alsa_output.pci-0000_09_00.3.analog-stereo"
SPEAKERS="alsa_output.pci-0000_07_00.1.hdmi-stereo-extra3"

CURRENT=$(pactl get-default-sink)

if [ "$CURRENT" = "$SPEAKERS" ]; then
    pactl set-default-sink "$HEADPHONES"
    NEW="$HEADPHONES"
else
    pactl set-default-sink "$SPEAKERS"
    NEW="$SPEAKERS"
fi

# Move all current playing audio to the new sink
for app in $(pactl list short sink-inputs | cut -f1); do
    pactl move-sink-input "$app" "$NEW"
done
