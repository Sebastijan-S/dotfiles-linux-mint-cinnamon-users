#!/bin/bash

i3lock \
--image="Sync/Media/Photo/Wallpaper/this.png" \
--blur=10 \
--indicator \
--radius=100 \
--ring-color=ffffff88 \
--keyhl-color=ff0000cc \
--bshl-color=0000ffcc \
--separator-color=00000000 \
--inside-color=00000088 \
--insidever-color=00000088 \
--insidewrong-color=00000088 \
--ringver-color=00ff00cc \
--ringwrong-color=ff0000cc \
--line-uses-inside \
--verif-text="Verifying…" \
--wrong-text="Wrong!" \
--noinput-text="No input" \
--time-color=ffffffff \
--date-color=ffffffff \
--layout-color=ffffffff \
--greeter-text="Locked by Seba 🔒" \
--greeter-color=ffffffff \
--greeter-pos="x+850:y+500" \
--time-pos="x+850:y+550" \
--date-pos="x+850:y+600"
